﻿using System;
using System.Collections.Generic;
using Entitestlager;
using DatalagerEF;

namespace Affärslager
{
    public class Bibliotek
    {
        //Alla operationer för anställd.
        public static Anställd InLoggad { get; private set; }
        public bool InLoggning(int anställningsNr, string lösenord)
        {
            unitOfWorkEF = new UnitOfWork();

            Anställd anställd = unitOfWorkEF.AnställdRepository.FirstOrDefault(a => a.Anställningsnummer == anställningsNr);
            if (anställd != null && anställd.KontrolleraLösenord(lösenord))
            {
                InLoggad = anställd;
                return true;
            }
            InLoggad = null;
            return false;
        }

        //Alla operationer för medlem.
        public Medlem valdMedlem { get; private set; }

        //Metod för att hitta medlem
        /*Tar in medlemsnummer som parameter och sen kollar ifall den 
        matchar något medlemsnummer som är sparat. Om ja så returnerar 
        den true.*/
        public bool KontrolleraMedlemsNummer(string medlemsNummerToParse)
        {
            int medlemsNr;
            int.TryParse(medlemsNummerToParse, out medlemsNr);
            Medlem medlem = unitOfWorkEF.MedlemRepository.FirstOrDefault(m => m.Medlemmsnummer == medlemsNr, m => m.Bokningar);
            if (medlem != null)
            {
                valdMedlem = medlem;
                return true;
            }   
            valdMedlem = null;
            return false;
            
        }


        // Hämtar alla tillgängliga böcker och lägger de i listan "tillgänglig"
        // returnerar Lista "tillgänglig" med alla tillgängliga böcker
        public List<Bok> HämtaTillgängligaBöcker(DateTime tilltänktUtlämningstid, DateTime tilltänktÅterlämningstid, Medlem medlem)
        {
            List<Bok> tillgängligaBöcker = new List<Bok>();
            foreach (Bok b in unitOfWorkEF.BokRepository.Find(b => b.Tillgänglighet))
            {
                tillgängligaBöcker.Add(b);

            }
            return tillgängligaBöcker;
        }

        // Sparar en bokning och tilldelar ett bokningsnummer.
        // Bokningen sparas i BokningsRepos och medlemmens bokningar uppdateras.
        //Returnerar bokkningsnummer som int.
        public Bokning SparaBokning(DateTime ttänktUtlämningstid, DateTime ttäntktÅterLämningstid, List<Bok> böcker, Medlem medlem)
        {
            //Risk för att bokningsNr blir samma ifall man tar bort bokning med bokningsnr BN0 och sedan lägger till en ny bokning ifall en bokning finns redan sen tidigare.
            //string bokningsnummer = "BN" + (unitOfWorkEF.BokningRepository.Count()).ToString();

            //Lösning
            string antalBokning = "BN" + (unitOfWorkEF.BokningRepository.Count()).ToString();
            Random random = new Random();
            int unikNr = random.Next(1, 999);
            string unikNrString = unikNr.ToString();
            string bokningsnummer = antalBokning + unikNrString;
            //Inte ett jätte bra sät ifall stor bibliotek, funkar dock utmärkt till mindre. 
            //-------------------------------------------------------------------------------------------

            Bokning bokning = new Bokning(ttänktUtlämningstid, ttäntktÅterLämningstid, InLoggad, valdMedlem, bokningsnummer);
            foreach (Bok bok in böcker)
            {
                bok.Tillgänglighet = false;
                bokning.Böcker.Add(bok);
            }
            unitOfWorkEF.BokningRepository.Add(bokning);
            unitOfWorkEF.Save();
            return bokning;
        }
        //Metod som säkerställer ifall det angivna bokningsnummret matchar en existerande bokning
        /* Om en bokning hittas så sätts den faktiska utlämningstiden till "nu", och det sparas i unitofwork. 
        Returnerar true om bokning hittas om inte så returneras värdet false. */
        public DateTime UtlämningAvBöcker(string bokningsnummer)
        {
            Bokning bokning = unitOfWorkEF.BokningRepository.FirstOrDefault(b => b.Bokningsnummer == bokningsnummer);
            if (bokning != null)
            {
                bokning.FaktiskUtlämningstid = DateTime.Today.Date;

            }
            Console.WriteLine(bokning.Bokningsnummer);
            unitOfWorkEF.Save();
            return bokning.FaktiskUtlämningstid;
        }
        // Metod för återlämningav böcker
        /* Tar in en bokning som parameter, slutligen lägger till den skapade
         * fakturan i FakturaRepository*/


        public Faktura ÅterlämningAvBöcker(Bokning bokning)
        {
            foreach (Bok bok in bokning.Böcker)
            {
                bok.Tillgänglighet = true;
            }

            DateTime faktisktÅterlämningstid = DateTime.Today;

            double totalpris;
            int räknaDagar = Convert.ToInt32((faktisktÅterlämningstid - bokning.TilltänktÅterlämningstid).TotalDays);
            if (faktisktÅterlämningstid > bokning.TilltänktÅterlämningstid) { totalpris = räknaDagar * 10; }


            else { totalpris = 0; }
            Faktura faktura = new Faktura(bokning, totalpris, faktisktÅterlämningstid, InLoggad.Anställningsnummer);
            

            unitOfWorkEF.FakturaRepository.Add(faktura);
            unitOfWorkEF.BokningRepository.Remove(bokning);
            unitOfWorkEF.Save();
            return faktura;
        }

        // Metod för att kontrollera om det angivna bokningsnummret matchar någon bokning.
        public Bokning KontrolleraBokningsNummer(string bokningsNummer)
        {
            return unitOfWorkEF.BokningRepository.FirstOrDefault(b => b.Bokningsnummer == bokningsNummer, b => b.Böcker);
        }

        private UnitOfWork unitOfWorkEF;

    }
}
