﻿namespace Presentationslager
{
    partial class LämnaUtBöckerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            LämnaUtBöcker_button = new System.Windows.Forms.Button();
            BokningsNr_label = new System.Windows.Forms.Label();
            Bokningar_listBox = new System.Windows.Forms.ListBox();
            Meny_button = new System.Windows.Forms.Button();
            MedlemsNr_textBox = new System.Windows.Forms.TextBox();
            BokningsNr_textBox = new System.Windows.Forms.TextBox();
            SökBokning_label = new System.Windows.Forms.Label();
            SökMedlem_label = new System.Windows.Forms.Label();
            MedlemsNr_button = new System.Windows.Forms.Button();
            SuspendLayout();
            // 
            // LämnaUtBöcker_button
            // 
            LämnaUtBöcker_button.Location = new System.Drawing.Point(190, 27);
            LämnaUtBöcker_button.Name = "LämnaUtBöcker_button";
            LämnaUtBöcker_button.Size = new System.Drawing.Size(126, 39);
            LämnaUtBöcker_button.TabIndex = 21;
            LämnaUtBöcker_button.Text = "Lämna ut böcker";
            LämnaUtBöcker_button.UseVisualStyleBackColor = true;
            LämnaUtBöcker_button.Click += LämnaUtBöcker_button_Click;
            // 
            // BokningsNr_label
            // 
            BokningsNr_label.AutoSize = true;
            BokningsNr_label.Location = new System.Drawing.Point(453, 69);
            BokningsNr_label.Name = "BokningsNr_label";
            BokningsNr_label.Size = new System.Drawing.Size(61, 15);
            BokningsNr_label.TabIndex = 20;
            BokningsNr_label.Text = "Bokningar";
            BokningsNr_label.Visible = false;
            // 
            // Bokningar_listBox
            // 
            Bokningar_listBox.AllowDrop = true;
            Bokningar_listBox.BackColor = System.Drawing.SystemColors.Window;
            Bokningar_listBox.CausesValidation = false;
            Bokningar_listBox.ForeColor = System.Drawing.SystemColors.WindowText;
            Bokningar_listBox.FormattingEnabled = true;
            Bokningar_listBox.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            Bokningar_listBox.ItemHeight = 15;
            Bokningar_listBox.Location = new System.Drawing.Point(454, 89);
            Bokningar_listBox.Name = "Bokningar_listBox";
            Bokningar_listBox.Size = new System.Drawing.Size(332, 79);
            Bokningar_listBox.TabIndex = 19;
            Bokningar_listBox.Visible = false;
            // 
            // Meny_button
            // 
            Meny_button.Location = new System.Drawing.Point(10, 181);
            Meny_button.Name = "Meny_button";
            Meny_button.Size = new System.Drawing.Size(75, 23);
            Meny_button.TabIndex = 18;
            Meny_button.Text = "Meny";
            Meny_button.UseVisualStyleBackColor = true;
            Meny_button.Click += Meny_button_Click;
            // 
            // MedlemsNr_textBox
            // 
            MedlemsNr_textBox.Location = new System.Drawing.Point(454, 31);
            MedlemsNr_textBox.Name = "MedlemsNr_textBox";
            MedlemsNr_textBox.Size = new System.Drawing.Size(160, 23);
            MedlemsNr_textBox.TabIndex = 17;
            // 
            // BokningsNr_textBox
            // 
            BokningsNr_textBox.Location = new System.Drawing.Point(10, 34);
            BokningsNr_textBox.Name = "BokningsNr_textBox";
            BokningsNr_textBox.Size = new System.Drawing.Size(160, 23);
            BokningsNr_textBox.TabIndex = 16;
            // 
            // SökBokning_label
            // 
            SökBokning_label.AutoSize = true;
            SökBokning_label.Location = new System.Drawing.Point(10, 16);
            SökBokning_label.Name = "SökBokning_label";
            SökBokning_label.Size = new System.Drawing.Size(133, 15);
            SökBokning_label.TabIndex = 15;
            SökBokning_label.Text = "Ange bokningsnummer";
            // 
            // SökMedlem_label
            // 
            SökMedlem_label.AutoSize = true;
            SökMedlem_label.Location = new System.Drawing.Point(454, 11);
            SökMedlem_label.Name = "SökMedlem_label";
            SökMedlem_label.Size = new System.Drawing.Size(169, 15);
            SökMedlem_label.TabIndex = 14;
            SökMedlem_label.Text = "Hitta bokning (sök medlemNr)";
            // 
            // MedlemsNr_button
            // 
            MedlemsNr_button.Location = new System.Drawing.Point(620, 27);
            MedlemsNr_button.Name = "MedlemsNr_button";
            MedlemsNr_button.Size = new System.Drawing.Size(85, 29);
            MedlemsNr_button.TabIndex = 13;
            MedlemsNr_button.Text = "Sök";
            MedlemsNr_button.UseVisualStyleBackColor = true;
            MedlemsNr_button.Click += MedlemsNr_button_Click;
            // 
            // LämnaUtBöckerForm
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(806, 212);
            Controls.Add(LämnaUtBöcker_button);
            Controls.Add(BokningsNr_label);
            Controls.Add(Bokningar_listBox);
            Controls.Add(Meny_button);
            Controls.Add(MedlemsNr_textBox);
            Controls.Add(BokningsNr_textBox);
            Controls.Add(SökBokning_label);
            Controls.Add(SökMedlem_label);
            Controls.Add(MedlemsNr_button);
            Name = "LämnaUtBöckerForm";
            Text = "Bibliotek -Lämna ut böcker";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button LämnaUtBöcker_button;
        private System.Windows.Forms.Label BokningsNr_label;
        private System.Windows.Forms.ListBox Bokningar_listBox;
        private System.Windows.Forms.Button Meny_button;
        private System.Windows.Forms.TextBox MedlemsNr_textBox;
        private System.Windows.Forms.TextBox BokningsNr_textBox;
        private System.Windows.Forms.Label SökBokning_label;
        private System.Windows.Forms.Label SökMedlem_label;
        private System.Windows.Forms.Button MedlemsNr_button;
    }
}