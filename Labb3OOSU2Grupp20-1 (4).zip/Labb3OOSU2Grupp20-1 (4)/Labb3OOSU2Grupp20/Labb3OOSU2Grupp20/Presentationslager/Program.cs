using Aff�rslager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentationslager
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            DatalagerEF.BibliotekContext bibliotekContext = new DatalagerEF.BibliotekContext();
            //Kommentera bort f�r att inte �terskapa databas.
            //bibliotekContext.Reset();

            //tweak to not terminate application if startup/master window/form is closed
            var main = new LoggaInForm(new Bibliotek (), "");
            main.FormClosed += new FormClosedEventHandler(FormClosed);
            main.Show();
            Application.Run();

            //Application.Run(new LoginForm(new CarPool()));
        }

        static void FormClosed(object sender, FormClosedEventArgs e)
        {
            ((Form)sender).FormClosed -= FormClosed;
            if (Application.OpenForms.Count == 0) Application.ExitThread();
            else Application.OpenForms[0].FormClosed += FormClosed;
        }
    }
    
}
