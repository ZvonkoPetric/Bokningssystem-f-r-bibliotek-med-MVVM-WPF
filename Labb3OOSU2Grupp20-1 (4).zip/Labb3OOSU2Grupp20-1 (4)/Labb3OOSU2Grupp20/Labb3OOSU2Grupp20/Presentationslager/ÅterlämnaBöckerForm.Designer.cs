﻿namespace Presentationslager
{
    partial class ÅterlämnaBöckerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            MedlemsNr_button = new System.Windows.Forms.Button();
            SökMedlem_label = new System.Windows.Forms.Label();
            SökBokning_label = new System.Windows.Forms.Label();
            BokningsNr_textBox = new System.Windows.Forms.TextBox();
            MedlemsNr_textBox = new System.Windows.Forms.TextBox();
            Meny_button = new System.Windows.Forms.Button();
            Bokningar_listBox = new System.Windows.Forms.ListBox();
            BokningsNr_label = new System.Windows.Forms.Label();
            SkapaFaktura_button = new System.Windows.Forms.Button();
            SuspendLayout();
            // 
            // MedlemsNr_button
            // 
            MedlemsNr_button.Location = new System.Drawing.Point(622, 27);
            MedlemsNr_button.Name = "MedlemsNr_button";
            MedlemsNr_button.Size = new System.Drawing.Size(85, 29);
            MedlemsNr_button.TabIndex = 0;
            MedlemsNr_button.Text = "Sök";
            MedlemsNr_button.UseVisualStyleBackColor = true;
            MedlemsNr_button.Click += MedlemsNr_button_Click;
            // 
            // SökMedlem_label
            // 
            SökMedlem_label.AutoSize = true;
            SökMedlem_label.Location = new System.Drawing.Point(456, 11);
            SökMedlem_label.Name = "SökMedlem_label";
            SökMedlem_label.Size = new System.Drawing.Size(169, 15);
            SökMedlem_label.TabIndex = 2;
            SökMedlem_label.Text = "Hitta bokning (sök medlemNr)";
            // 
            // SökBokning_label
            // 
            SökBokning_label.AutoSize = true;
            SökBokning_label.Location = new System.Drawing.Point(12, 16);
            SökBokning_label.Name = "SökBokning_label";
            SökBokning_label.Size = new System.Drawing.Size(133, 15);
            SökBokning_label.TabIndex = 3;
            SökBokning_label.Text = "Ange bokningsnummer";
            // 
            // BokningsNr_textBox
            // 
            BokningsNr_textBox.Location = new System.Drawing.Point(12, 34);
            BokningsNr_textBox.Name = "BokningsNr_textBox";
            BokningsNr_textBox.Size = new System.Drawing.Size(160, 23);
            BokningsNr_textBox.TabIndex = 4;
            // 
            // MedlemsNr_textBox
            // 
            MedlemsNr_textBox.Location = new System.Drawing.Point(456, 31);
            MedlemsNr_textBox.Name = "MedlemsNr_textBox";
            MedlemsNr_textBox.Size = new System.Drawing.Size(160, 23);
            MedlemsNr_textBox.TabIndex = 5;
            // 
            // Meny_button
            // 
            Meny_button.Location = new System.Drawing.Point(12, 181);
            Meny_button.Name = "Meny_button";
            Meny_button.Size = new System.Drawing.Size(75, 23);
            Meny_button.TabIndex = 6;
            Meny_button.Text = "Meny";
            Meny_button.UseVisualStyleBackColor = true;
            Meny_button.Click += Meny_button_Click;
            // 
            // Bokningar_listBox
            // 
            Bokningar_listBox.AllowDrop = true;
            Bokningar_listBox.BackColor = System.Drawing.SystemColors.Window;
            Bokningar_listBox.CausesValidation = false;
            Bokningar_listBox.ForeColor = System.Drawing.SystemColors.WindowText;
            Bokningar_listBox.FormattingEnabled = true;
            Bokningar_listBox.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            Bokningar_listBox.ItemHeight = 15;
            Bokningar_listBox.Location = new System.Drawing.Point(456, 89);
            Bokningar_listBox.Name = "Bokningar_listBox";
            Bokningar_listBox.Size = new System.Drawing.Size(332, 79);
            Bokningar_listBox.TabIndex = 7;
            Bokningar_listBox.Visible = false;
            // 
            // BokningsNr_label
            // 
            BokningsNr_label.AutoSize = true;
            BokningsNr_label.Location = new System.Drawing.Point(455, 69);
            BokningsNr_label.Name = "BokningsNr_label";
            BokningsNr_label.Size = new System.Drawing.Size(61, 15);
            BokningsNr_label.TabIndex = 8;
            BokningsNr_label.Text = "Bokningar";
            BokningsNr_label.Visible = false;
            // 
            // SkapaFaktura_button
            // 
            SkapaFaktura_button.Location = new System.Drawing.Point(192, 27);
            SkapaFaktura_button.Name = "SkapaFaktura_button";
            SkapaFaktura_button.Size = new System.Drawing.Size(126, 39);
            SkapaFaktura_button.TabIndex = 12;
            SkapaFaktura_button.Text = "Återlämna böcker";
            SkapaFaktura_button.UseVisualStyleBackColor = true;
            SkapaFaktura_button.Click += SkapaFaktura_button_Click;
            // 
            // ÅterlämnaBöckerForm
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(800, 210);
            Controls.Add(SkapaFaktura_button);
            Controls.Add(BokningsNr_label);
            Controls.Add(Bokningar_listBox);
            Controls.Add(Meny_button);
            Controls.Add(MedlemsNr_textBox);
            Controls.Add(BokningsNr_textBox);
            Controls.Add(SökBokning_label);
            Controls.Add(SökMedlem_label);
            Controls.Add(MedlemsNr_button);
            Name = "ÅterlämnaBöckerForm";
            Text = "Bibliotek - Återlämna böcker";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button MedlemsNr_button;
        private System.Windows.Forms.Label SökMedlem_label;
        private System.Windows.Forms.Label SökBokning_label;
        private System.Windows.Forms.TextBox BokningsNr_textBox;
        private System.Windows.Forms.TextBox MedlemsNr_textBox;
        private System.Windows.Forms.Button Meny_button;
        private System.Windows.Forms.ListBox Bokningar_listBox;
        private System.Windows.Forms.Label BokningsNr_label;
        private System.Windows.Forms.Button SkapaFaktura_button;
    }
}