﻿using Affärslager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Presentationslager
{
    public partial class MenyForm : Form
    {
        private Bibliotek bibliotek;
        public MenyForm(Bibliotek bibliotek)
        {
            InitializeComponent();
            this.CenterToScreen();
            this.bibliotek = bibliotek;
            Datum_label.Text = DateTime.Now.ToString("yyyy-MM-dd");
        }

        private void SkapaBokning_button_Click(object sender, EventArgs e)
        {
            this.Close();
            new SkapaBokningForm(bibliotek).Show();
        }

        private void LämnaUtBöcker_button_Click(object sender, EventArgs e)
        {
            this.Close();
            new LämnaUtBöckerForm(bibliotek).Show();
        }

        private void Loggaut_button_Click(object sender, EventArgs e)
        {
            this.Close();
            new LoggaInForm(bibliotek, "").Show();
        }

        private void ÅterlämnaBöcker_Button_Click(object sender, EventArgs e)
        {
            this.Close();
            new ÅterlämnaBöckerForm(bibliotek).Show();
        }
    }
}
