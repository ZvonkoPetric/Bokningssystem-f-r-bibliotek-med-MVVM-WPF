﻿using Affärslager;
using Entitestlager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Presentationslager
{
    public partial class LämnaUtBöckerForm : Form
    {
        private Bibliotek bibliotek;
        public LämnaUtBöckerForm(Bibliotek bibliotek)
        {
            InitializeComponent();
            this.bibliotek = bibliotek;
            this.CenterToScreen();
        }

        private void MedlemsNr_button_Click(object sender, EventArgs e)
        {
            if (bibliotek.KontrolleraMedlemsNummer(MedlemsNr_textBox.Text) == true && bibliotek.valdMedlem.Bokningar != null)
            {
                SökMedlem_label.ForeColor = Color.Black;
                Bokningar_listBox.Items.Clear();
                Bokningar_listBox.Visible = true;
                BokningsNr_label.Visible = true;

                foreach (Bokning bokning in bibliotek.valdMedlem.Bokningar)
                {
                    Bokningar_listBox.Items.Add("Boknings nummer: " + bokning.Bokningsnummer);
                    Bokningar_listBox.Items.Add("Tilltänkt utlämningstid: " + bokning.TilltänktUtlämningstid.Date.ToString("yyyy-MM--dd"));
                    Bokningar_listBox.Items.Add("Tilltänkt återlämningstid: " + bokning.TilltänktÅterlämningstid.Date.ToString("yyyy-MM--dd"));
                    Bokningar_listBox.Items.Add("-------------------------------------------\n\n");
                }
                //Ifall medlem inte har några bokningar 
                if (Bokningar_listBox.Items.Count == 0)
                {
                    Bokningar_listBox.Visible = false;
                    BokningsNr_label.Visible = false;

                    SökMedlem_label.ForeColor = Color.Red;
                    SökMedlem_label.Text = "Medlem har inga bokningar!";
                }
            }
            if (bibliotek.KontrolleraMedlemsNummer(MedlemsNr_textBox.Text) == false)
            {
                Bokningar_listBox.Visible = false;
                BokningsNr_label.Visible = false;

                SökMedlem_label.ForeColor = Color.Red;
                SökMedlem_label.Text = "Medlem kunde inte hittas!";
            }
        }

        private void Meny_button_Click(object sender, EventArgs e)
        {
            this.Close();
            new MenyForm(bibliotek).Show();
        }

        private void LämnaUtBöcker_button_Click(object sender, EventArgs e)
        {
            string bokningsNr = BokningsNr_textBox.Text;

            Bokning bokning = bibliotek.KontrolleraBokningsNummer(bokningsNr);

            if (bokning != null)
            {
                if(bokning.TilltänktUtlämningstid < DateTime.Today.Date)
                {
                    SökBokning_label.ForeColor = Color.Black;
                    SökBokning_label.Text = "Ange bokningsnummer";

                    DateTime faktisktUtlämning = bibliotek.UtlämningAvBöcker(bokning.Bokningsnummer);

                    MessageBox.Show("Böckerna har nu lämnats ut, utlämningstiden är: " + faktisktUtlämning.ToString("yyyy-MM-dd"));
                    this.Close();
                    new MenyForm(bibliotek).Show();

                }
                else { MessageBox.Show("Böckerna kan inte lämnas ut tidigare än lånets startdatum."); }
            }
            
            else
            {
                SökBokning_label.ForeColor = Color.Red;
                SökBokning_label.Text = "Bokning kunde inte hittas!";
            }
        }
    }
}
