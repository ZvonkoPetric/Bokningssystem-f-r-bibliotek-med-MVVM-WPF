﻿namespace Presentationslager
{
    partial class MenyForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            SkapaBokning_button = new System.Windows.Forms.Button();
            LämnaUtBöcker_button = new System.Windows.Forms.Button();
            Expedit_label = new System.Windows.Forms.Label();
            ExpeditNr_label = new System.Windows.Forms.Label();
            Datum_label = new System.Windows.Forms.Label();
            Loggaut_button = new System.Windows.Forms.Button();
            ÅterlämnaBöcker_Button = new System.Windows.Forms.Button();
            SuspendLayout();
            // 
            // SkapaBokning_button
            // 
            SkapaBokning_button.Location = new System.Drawing.Point(69, 65);
            SkapaBokning_button.Name = "SkapaBokning_button";
            SkapaBokning_button.Size = new System.Drawing.Size(137, 49);
            SkapaBokning_button.TabIndex = 0;
            SkapaBokning_button.Text = "Skapa en bokning";
            SkapaBokning_button.UseVisualStyleBackColor = true;
            SkapaBokning_button.Click += SkapaBokning_button_Click;
            // 
            // LämnaUtBöcker_button
            // 
            LämnaUtBöcker_button.Location = new System.Drawing.Point(69, 136);
            LämnaUtBöcker_button.Name = "LämnaUtBöcker_button";
            LämnaUtBöcker_button.Size = new System.Drawing.Size(137, 51);
            LämnaUtBöcker_button.TabIndex = 1;
            LämnaUtBöcker_button.Text = "Lämna ut böcker";
            LämnaUtBöcker_button.UseVisualStyleBackColor = true;
            LämnaUtBöcker_button.Click += LämnaUtBöcker_button_Click;
            // 
            // Expedit_label
            // 
            Expedit_label.AutoSize = true;
            Expedit_label.Location = new System.Drawing.Point(12, 9);
            Expedit_label.Name = "Expedit_label";
            Expedit_label.Size = new System.Drawing.Size(92, 15);
            Expedit_label.TabIndex = 4;
            Expedit_label.Text = "Expedit: Larsson";
            // 
            // ExpeditNr_label
            // 
            ExpeditNr_label.AutoSize = true;
            ExpeditNr_label.Location = new System.Drawing.Point(12, 33);
            ExpeditNr_label.Name = "ExpeditNr_label";
            ExpeditNr_label.Size = new System.Drawing.Size(82, 15);
            ExpeditNr_label.TabIndex = 5;
            ExpeditNr_label.Text = "Ex Nummer: 1";
            // 
            // Datum_label
            // 
            Datum_label.AutoSize = true;
            Datum_label.Location = new System.Drawing.Point(12, 308);
            Datum_label.Name = "Datum_label";
            Datum_label.Size = new System.Drawing.Size(0, 15);
            Datum_label.TabIndex = 6;
            // 
            // Loggaut_button
            // 
            Loggaut_button.Location = new System.Drawing.Point(167, 289);
            Loggaut_button.Name = "Loggaut_button";
            Loggaut_button.Size = new System.Drawing.Size(93, 31);
            Loggaut_button.TabIndex = 7;
            Loggaut_button.Text = "Logga ut";
            Loggaut_button.UseVisualStyleBackColor = true;
            Loggaut_button.Click += Loggaut_button_Click;
            // 
            // ÅterlämnaBöcker_Button
            // 
            ÅterlämnaBöcker_Button.Location = new System.Drawing.Point(69, 213);
            ÅterlämnaBöcker_Button.Name = "ÅterlämnaBöcker_Button";
            ÅterlämnaBöcker_Button.Size = new System.Drawing.Size(137, 51);
            ÅterlämnaBöcker_Button.TabIndex = 8;
            ÅterlämnaBöcker_Button.Text = "Återlämna böcker";
            ÅterlämnaBöcker_Button.UseVisualStyleBackColor = true;
            ÅterlämnaBöcker_Button.Click += ÅterlämnaBöcker_Button_Click;
            // 
            // MenyForm
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(272, 332);
            Controls.Add(ÅterlämnaBöcker_Button);
            Controls.Add(Loggaut_button);
            Controls.Add(Datum_label);
            Controls.Add(ExpeditNr_label);
            Controls.Add(Expedit_label);
            Controls.Add(LämnaUtBöcker_button);
            Controls.Add(SkapaBokning_button);
            Name = "MenyForm";
            Text = "Bibliotek - Meny";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button SkapaBokning_button;
        private System.Windows.Forms.Button LämnaUtBöcker_button;
        private System.Windows.Forms.Label Expedit_label;
        private System.Windows.Forms.Label ExpeditNr_label;
        private System.Windows.Forms.Label Datum_label;
        private System.Windows.Forms.Button Loggaut_button;
        private System.Windows.Forms.Button ÅterlämnaBöcker_Button;
    }
}