﻿using Affärslager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentationslager
{
    public partial class LoggaInForm : Form
    {
        private Bibliotek bibliotek;
        public LoggaInForm(Bibliotek bibliotek, string returnMessage)
        {
            InitializeComponent();
            this.CenterToScreen();
            this.bibliotek = bibliotek;


        }

        private void LoggaIn_button_Click(object sender, EventArgs e)
        {
            string anv = Användare_textBox.Text;
            int användarNummer = Convert.ToInt32(anv);
            if (bibliotek.InLoggning(användarNummer, Lösenord_textBox.Text) != false)
            {
                this.Hide();
                new MenyForm(bibliotek).Show();
            }
            else { FailLogin_label.Text = "Inloggning misslyckades, försök igen!"; }
        }
    }
}
