﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Entitestlager
{
    public class Bokning
    {
        private Bokning() { }

        [Key]
        public int BokningID { get; set; }

        public DateTime TilltänktUtlämningstid { get; private set; }
        public DateTime TilltänktÅterlämningstid { get; private set; }
        public DateTime FaktiskUtlämningstid { get; set; }

        public Anställd Anställd { get; private set; }


        public List<Bok> Böcker { get; set; }
        public Medlem Medlem { get; private set; }


        public string Bokningsnummer { get; private set; }

        public Bokning(DateTime Tilltänktutlämningstid, DateTime TilltänktÅterlämningstid,
            Anställd Anställd, Medlem Medlem, string Bokningsnummer)
        {
            this.TilltänktUtlämningstid = Tilltänktutlämningstid;
            this.TilltänktÅterlämningstid = TilltänktÅterlämningstid;
            this.Medlem = Medlem;
            this.Anställd = Anställd;
            this.Bokningsnummer = Bokningsnummer;
            Böcker = new List<Bok>();
        }
    }
}
