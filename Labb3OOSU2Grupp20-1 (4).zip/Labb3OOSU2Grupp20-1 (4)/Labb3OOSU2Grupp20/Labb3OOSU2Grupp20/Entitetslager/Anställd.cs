﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Entitestlager
{
    public class Anställd
    {
        private Anställd() { }

        [Key]
        public int AnställningID { get; set; }


        public int Anställningsnummer { get; private set; }
        public string Namn { get; private set; }
        public string Lösenord { get; private set; }
        public string Roll { get; private set; }

        public Anställd(int Anställningsnummer, string Namn, string Lösenord, string Roll)
        {
            this.Anställningsnummer = Anställningsnummer;
            this.Namn = Namn;
            this.Lösenord = Lösenord;
            this.Roll = Roll;
        }

        public bool KontrolleraLösenord(string given)
        {
            return Lösenord == given;
        }
    }
}
