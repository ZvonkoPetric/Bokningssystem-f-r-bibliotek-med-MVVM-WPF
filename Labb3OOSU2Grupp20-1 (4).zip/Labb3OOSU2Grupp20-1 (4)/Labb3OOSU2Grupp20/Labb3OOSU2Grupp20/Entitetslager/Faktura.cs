﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Entitestlager
{
    public class Faktura
    {
        private Faktura() { }

        [Key]
        public int FaktruaID { get; set; }

        public double Totalpris { get; set; }
        public int Fakturanummer { get; set; }

        public Bokning bokning { get; private set; }
        public DateTime FaktiskÅterlämningstid { get; private set; }
        public int Anställningsnummer { get; private set; }

        static int fakturanummer { get; set; }

        public Faktura(Bokning Bokning, double Totalpris, DateTime FaktiskÅterlämningstid, int anställningsnummer)
        {
            Fakturanummer = fakturanummer++;
            this.bokning = Bokning;
            this.Totalpris = Totalpris;
            this.FaktiskÅterlämningstid = FaktiskÅterlämningstid;
            Anställningsnummer = anställningsnummer;
        }
    }
}
