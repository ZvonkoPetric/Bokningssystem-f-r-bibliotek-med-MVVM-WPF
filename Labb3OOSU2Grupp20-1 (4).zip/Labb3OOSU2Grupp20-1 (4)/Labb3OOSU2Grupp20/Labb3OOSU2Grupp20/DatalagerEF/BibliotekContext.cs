﻿using Entitestlager;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;

namespace DatalagerEF
{
    public class BibliotekContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //Skapa lokal server, lägg sedan till connection string så funkar programmet.
            optionsBuilder.UseSqlServer("");
            base.OnConfiguring(optionsBuilder);
        }

        DbSet<Anställd> Anställda { get; set; }
        DbSet<Bok> Böcker { get; set; }
        DbSet<Bokning> Bokningar { get; set; }
        DbSet<Faktura> Fakturor { get; set; }
        DbSet<Medlem> Medlemmar { get; set; }

        public void Reset()
        {   
            Database.EnsureCreated();

            Anställda.Add(new Anställd(1, "Zvonko", "123", "Expedit"));
            Anställda.Add(new Anställd(2, "Zvonkeke", "345", "Expedit"));

            Medlemmar.Add(new Medlem(10, "Larsson", 0701111111, "Larsson@hotmail.com"));
            Medlemmar.Add(new Medlem(11, "Henrik", 0702223313, "Herik@hotmail.com"));

            Böcker.Add(new Bok(100, "Sagan om ringen", true));
            Böcker.Add(new Bok(101, "Bröderna Lejonhjärta", true));
            Böcker.Add(new Bok(102, "Pettson & Findus", true));
            Böcker.Add(new Bok(103, "Fast & Furious", true));
            Böcker.Add(new Bok(104, "Harry Potter", true));


            SaveChanges();
        }
    }
}

