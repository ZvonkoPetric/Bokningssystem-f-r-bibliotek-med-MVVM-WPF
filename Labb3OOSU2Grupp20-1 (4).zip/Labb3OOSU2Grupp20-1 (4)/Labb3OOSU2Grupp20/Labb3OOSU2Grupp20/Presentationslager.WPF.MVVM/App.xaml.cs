﻿using DatalagerEF;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace Presentationslager.WPF.MVVM
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public App()
        {
            BibliotekContext dBcontext = new BibliotekContext();
            //Kommentera bort för att inte återställa database.
            dBcontext.Reset();
        }
      
        
    }
}
