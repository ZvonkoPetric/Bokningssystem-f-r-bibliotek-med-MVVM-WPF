﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Presentationslager.WPF.MVVM.Services
{
    public interface ICloseable
    {
        void Close();
        bool? DialogResult { get; set; }
    }
}
