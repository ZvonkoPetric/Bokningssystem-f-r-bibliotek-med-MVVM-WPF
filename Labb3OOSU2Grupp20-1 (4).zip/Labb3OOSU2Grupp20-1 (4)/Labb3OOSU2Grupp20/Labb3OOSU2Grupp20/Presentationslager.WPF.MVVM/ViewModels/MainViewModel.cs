﻿using Affärslager;
using Entitestlager;
using Microsoft.EntityFrameworkCore.Migrations.Operations;
using Microsoft.EntityFrameworkCore.Query.Internal;
using Presentationslager.WPF.MVVM.Commands;
using Presentationslager.WPF.MVVM.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Input;

namespace Presentationslager.WPF.MVVM.ViewModels
{
    class MainViewModel : ObservableObject
    {
        private readonly Bibliotek bibliotek;

        public MainViewModel()
        {
            bibliotek = new Bibliotek();
            bibliotek.InLoggning(1, "123");//Hårdkodar inlogg, se förklaring i inlämning.
            Böcker = new ObservableCollection<Bok>();
            Bokningar = new ObservableCollection<Bokning>();
        }
        //Sektion för skapa Bokning tab-----------------------------------------------------------------------------------------------
        private bool isNotModified = true;
        public bool IsNotModified { get { return isNotModified; } set { isNotModified = value; OnPropertyChanged(); } }

        private ObservableCollection<Bok> böcker = null!;
        public ObservableCollection<Bok> Böcker { get => böcker; set { böcker = value; OnPropertyChanged(); } }

        private ICommand sökTillgängligaBöcker = null!;
        public ICommand SökTillgängligaBöcker =>
            sökTillgängligaBöcker ??= sökTillgängligaBöcker = new RelayCommand(() =>
            {
                Böcker.Clear();
                List<Bok> b = new List<Bok>();
                b = bibliotek.HämtaTillgängligaBöcker(TtUtlämningsDatum, ttÅterlämningsDatum, bibliotek.valdMedlem);
                foreach(Bok bok in b)
                {
                    Böcker.Add(bok);
                }
            });

        private ICommand taBortBöcker = null!;
        public ICommand TaBortBöcker =>
            taBortBöcker ??= taBortBöcker = new RelayCommand(() =>
            {
                ValdaBöcker.Clear();
            });

        private int medlesmNummer;
        public int MedlemsNummer
        {
            get { return medlesmNummer; }
            set { medlesmNummer = value; OnPropertyChanged(); }
        }

        private ICommand sökMedlem = null!;
        public ICommand SökMedlem => sökMedlem ??= sökMedlem = new RelayCommand(() =>
        {
            string MedlemsNrParsed = MedlemsNummer.ToString();

            if (bibliotek.KontrolleraMedlemsNummer(MedlemsNrParsed) == true)
            {
                MessageBox.Show("Vald medlem: " + bibliotek.valdMedlem.Namn);
            }
            if (bibliotek.KontrolleraMedlemsNummer(MedlemsNrParsed) == false)
            {
                MessageBox.Show("Medlem kunde inte hiitas, försök igen!");
            }
        });

        private DateTime ttUtlämningsDatum = DateTime.Now;
        public DateTime TtUtlämningsDatum
        {
            get { return ttUtlämningsDatum; }
            set { ttUtlämningsDatum = value; OnPropertyChanged(); }
        }

        private DateTime ttÅterlämningsDatum = DateTime.Now;
        public DateTime TtÅterlämningsDatum
        {
            get { return ttÅterlämningsDatum; }
            set { ttÅterlämningsDatum = value; OnPropertyChanged(); }
        }

        //Valda böcker finns i denna Collcetion (Grid).
        private ObservableCollection<Bok> valdaBöcker = new ObservableCollection<Bok>();
        public ObservableCollection<Bok> ValdaBöcker
        {
            get { return valdaBöcker; }
            set
            {
                valdaBöcker = value;
                OnPropertyChanged();
            }
        }

        //Knapp lägg till bok

        private bool läggTill = false;
        public bool LäggTill
        {
            get { return läggTill; }
            set { läggTill = value; OnPropertyChanged(); }
        }

        private ICommand läggTillBöcker = null!;
        public ICommand LäggTillBöcker =>
            läggTillBöcker ??= läggTillBöcker = new RelayCommand(() =>
            {
                ValdaBöcker.Add(ValdBok);
                Böcker.Remove(ValdBok);
            });

        private Bok valdBok;
        public Bok ValdBok
        {
            get { return valdBok; }
            set
            {
                valdBok = value;
                if (valdBok != null) LäggTill= true;
                else LäggTill = false;
                OnPropertyChanged();
            }
        }

        //Skapa Bokning command (Boka knapp)
        private ICommand skapaBokning = null!;
        public ICommand SkapaBokning =>
            skapaBokning ??= skapaBokning = new RelayCommand(() =>
            {
                List<Bok> valdaBöckerLista = new List<Bok>();
                foreach (Bok b in ValdaBöcker)
                {
                    valdaBöckerLista.Add(b);
                }

                if (valdaBöckerLista.Count > 0 && bibliotek.valdMedlem != null)
                {
                    
                    Bokning bokning = bibliotek.SparaBokning(TtUtlämningsDatum, TtÅterlämningsDatum, valdaBöckerLista, bibliotek.valdMedlem);
                    MessageBox.Show("Bokningen är nu skapad, BokningsNr: " + bokning.Bokningsnummer);
                    ValdaBöcker.Clear();
                }
                if (valdaBöckerLista.Count < 1)
                {
                    MessageBox.Show("Du måste lägga till böcker.");
                }
                if (bibliotek.valdMedlem == null)
                {
                    MessageBox.Show("Du måste välja en medlem.");
                }
            });
        //--------------------------------------------------------------------------------------------------------------------------------------------

        //Sektion för Återlämna Bokning tab-----------------------------------------------------------------------------------------------------------

        private string bokningsNummer;
        public string BokningsNummer
        {
            get { return bokningsNummer; }
            set { bokningsNummer = value; OnPropertyChanged(); }
        }
      

        private ICommand skapaFaktura = null!;
        public ICommand SkapaFaktura =>
            skapaFaktura ??= skapaFaktura = new RelayCommand(() =>
            {
                Bokning bokning = bibliotek.KontrolleraBokningsNummer(BokningsNummer);

                if(bokning != null)
                {
                    Faktura faktura =  bibliotek.ÅterlämningAvBöcker(bokning);
                    MessageBox.Show("Bokningen är nu återlämna, faktura nummer: " + faktura.Fakturanummer
                        + "\nVår referens: " + faktura.Anställningsnummer + "\nPris: " + faktura.Totalpris);
                }
                if (bokning == null)
                {
                    MessageBox.Show("Bokning kunde inte hittas, försök igen.");
                }
            });

        //Söker efter medlemmens bokningar
        private ICommand sökBokningar = null!;
        public ICommand SökBokningar =>
            sökBokningar ??= sökBokningar = new RelayCommand(() =>
            {
                Bokningar.Clear();
                if (bibliotek.KontrolleraMedlemsNummer(MedlemsNummer.ToString()) == true)
                {
                    if(bibliotek.valdMedlem.Bokningar.Count > 0)
                    {
                        foreach (Bokning bokning in bibliotek.valdMedlem.Bokningar)
                        {
                            Bokningar.Add(bokning);
                        }
                    }
                    if (bibliotek.valdMedlem.Bokningar.Count < 1)
                    {
                        MessageBox.Show("Medlem har inga bokningar");
                    }
                }

                if(bibliotek.KontrolleraMedlemsNummer(MedlemsNummer.ToString()) == false)
                {
                    MessageBox.Show("Medlem kunde inte hittas, försök igen!");
                }
            });

        private ObservableCollection<Bokning> bokningar = null!;
        public ObservableCollection<Bokning> Bokningar { get => bokningar; set { bokningar = value; OnPropertyChanged(); } }

        //--------------------------------------------------------------------------------------------------------------------------------------------


        //Sektion för Lämna ut böcker tab-----------------------------------------------------------------------------------------------------------

        private ICommand lämnaUtBöcker = null!;
        public ICommand LämnaUtBöcker =>
            lämnaUtBöcker ??= lämnaUtBöcker = new RelayCommand(() =>
            {
                Bokning bokning = bibliotek.KontrolleraBokningsNummer(BokningsNummer);

                if (bokning != null)
                {
                    bibliotek.UtlämningAvBöcker(BokningsNummer);
                    MessageBox.Show("Böckerna har nu lämnats ut.");
                }
                if (bokning == null)
                {
                    MessageBox.Show("Bokning kunde inte hittas försök igen!");
                }
            });
    }
}
